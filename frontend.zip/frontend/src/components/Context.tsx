import * as React from "react";

const QuizzesContext = React.createContext([]);

export { QuizzesContext }; 
